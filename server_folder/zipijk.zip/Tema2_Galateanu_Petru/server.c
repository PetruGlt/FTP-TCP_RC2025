#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PORT 2022
#define BUFF_SIZE 1024

struct account
{
    char username[100];
    char password[100];
};

void decrypt(char pass[100])
{
    char a;
    int i = 0;
    int n = strlen(pass);

    while (i < n)
    {
        switch (pass[i])
        {
        case '%':
            pass[i] = 'a';
            break;
        case '@':
            pass[i] = 'b';
            break;
        case ')':
            pass[i] = 'c';
            break;
        case '&':
            pass[i] = 'd';
            break;
        case '$':
            pass[i] = 'e';
            break;
        case '#':
            pass[i] = 'f';
            break;
        case ';':
            pass[i] = 'g';
            break;
        case '1':
            pass[i] = 'h';
            break;
        case 'p':
            pass[i] = 'i';
            break;
        case '^':
            pass[i] = 'j';
            break;
        case 'y':
            pass[i] = 'k';
            break;
        case '-':
            pass[i] = 'l';
            break;
        case '}':
            pass[i] = 'm';
            break;
        case ':':
            pass[i] = 'n';
            break;
        case '4':
            pass[i] = 'o';
            break;
        case '+':
            pass[i] = 'p';
            break;
        case '`':
            pass[i] = 'q';
            break;
        case 's':
            pass[i] = 'r';
            break;
        case '>':
            pass[i] = 's';
            break;
        case '<':
            pass[i] = 't';
            break;
        case '~':
            pass[i] = 'u';
            break;
        case 'r':
            pass[i] = 'v';
            break;
        case 'a':
            pass[i] = 'w';
            break;
        case 'Y':
            pass[i] = 'x';
            break;
        case '7':
            pass[i] = 'y';
            break;
        case '"':
            pass[i] = 'z';
            break;

        case 'R':
            pass[i] = '1';
            break;
        case 'V':
            pass[i] = '2';
            break;
        case 'Q':
            pass[i] = '3';
            break;
        case 'T':
            pass[i] = '4';
            break;
        case 'Z':
            pass[i] = '5';
            break;
        case 'W':
            pass[i] = '6';
            break;
        case 'S':
            pass[i] = '7';
            break;
        case '.':
            pass[i] = '8';
            break;
        case 'i':
            pass[i] = '9';
            break;
        case 'D':
            pass[i] = '0';
            break;

        case '_':
            pass[i] = '!';
            break;
        case '!':
            pass[i] = '@';
            break;
        case 'C':
            pass[i] = '.';
            break;
        default:
            break;
        }
        i++;
    }
}

extern int errno;


int account_verify(const char *username, const char *password)
{
    FILE *file = fopen("whitelist.txt", "r");
    if (file == NULL)
    {
        perror("[server] can't open whitelist.txt");
        return 0;
    }

    char file_username[50];
    char file_password[50];

    while (fscanf(file, "%s %s", file_username, file_password) != EOF)
    {
        if (strcmp(username, file_username) == 0 && strcmp(password, file_password) == 0)
        {
            fclose(file);
            return 1;
        }
    }
    fclose(file);
    return 0;
}

void client_handler(int client_socket, int id)
{
    struct account acc;
    int n;
    int connected = 0;
    char buff[BUFF_SIZE];

    n = recv(client_socket, &acc, sizeof(acc), 0);

    if (n < 0)
    {
        perror("[server] error recieving data from client");
        close(client_socket);
        return;
    }
    decrypt(acc.password);
    if (account_verify(acc.username, acc.password))
    {
        send(client_socket, "[server] Account found! Connected!", strlen("[server] Account found! Connected!"), 0);
        printf("[server] Account with ID: %d logged\n", id);
        connected = 1;
    }
    else
    {
        send(client_socket, "[server] Failed to connect! Account not found!", strlen("[server] Failed to connect! Account not found!"), 0);
    }
    while (connected)
    {
        memset(buff, 0, BUFF_SIZE);
        n = recv(client_socket, buff, BUFF_SIZE - 1, 0);

        buff[n] = '\0';
        buff[strcspn(buff, "\r\n")] = '\0';

        char command[BUFF_SIZE];
        sscanf(buff, "%s", command);

        if (strncmp(buff, "exit", 4) == 0)
        {
            send(client_socket, "[server] Goodbye!\n", strlen("[server] Goodbye!\n"), 0);
            connected = 0;
        }

        else if (strncmp(command, "mkdir", 5) == 0)
        {
            char directory_name[BUFF_SIZE];
            sscanf(buff + 6, "%s", directory_name);

            if (mkdir(directory_name, 0777) == 0)
                send(client_socket, "[server]Directory created successfully!", strlen("[server]Directory %s created successfully!"), 0);
            else
                send(client_socket, "[server]Failed to create directory", strlen("[server]Failed to create directory"), 0);
        }

        else if (strncmp(command, "rename", 6) == 0)
        {
            char old_name[BUFF_SIZE], new_name[BUFF_SIZE];
            sscanf(buff + 7, "%s %s", old_name, new_name);

            if (rename(old_name, new_name) == 0)
                send(client_socket, "[server]File renamed successfully", strlen("[server]File renamed successfully"), 0);

            else
            {
                send(client_socket, "[server]Failed to rename the specified file", strlen("[server]Failed to rename the specified file"), 0);
            }
        }
        else if (strncmp(command, "delete", 6) == 0)
        {
            char file_to_delete[BUFF_SIZE];
            sscanf(buff + 7, "%s", file_to_delete);

            if (strncmp(file_to_delete, "server", 6) != 0 && strncmp(file_to_delete, "client", 6) != 0 && strncmp(file_to_delete, "whitelist", 9) != 0)
                if (remove(file_to_delete) == 0)
                {
                    send(client_socket, "File deleted!", strlen("File deleted!"), 0);
                }
                else
                {
                    send(client_socket, "Can't delete the file", strlen("Can't delete the file"), 0);
                }
            else
                send(client_socket, "You are not allowed to delete that file", strlen("You are not allowed to delete that file"), 0);
        }
        else if (strncmp(command, "help", 4) == 0)
        {
            const char *help =
                "\n[server] Available command list:\n"
                " > mkdir <dir_name> : creates a new directory named as specified.\n"
                " > rename <file_to_be_renamed> <new_name> : changes the name of the <file_to_be_renamed> to <new_name>\n"
                " > delete <file> : removes the file\n";

            send(client_socket, help, strlen(help), 0);
        }

        else
            send(client_socket, "[server]Unknown command", strlen("[server]Unknown command"), 0);
    }

    close(client_socket);
}
int main()
{
    struct sockaddr_in server;
    struct sockaddr_in client;
    int server_socket;
    int client_socket;
    socklen_t client_length = sizeof(client);
    int connected = 0;
    int id = 0;

    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("[server] socket() failed\n");
        return errno;
    }

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = htonl(INADDR_ANY);
    server.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr *)&server, sizeof(struct sockaddr)) == -1)
    {
        perror("[server]bind() failed\n");
        return errno;
    }

    if (listen(server_socket, 5) == -1)
    {
        perror("[server]listen() failed\n");
        return errno;
    }

    while (1)
    {
        printf("[server] Ready to recieve clients at port %d... \n", PORT);

        client_socket = accept(server_socket, (struct sockaddr *)&client, &client_length);

        if (client_socket < 0)
        {
            perror("[server]accept() failure");
            continue;
        }

        id++;

        printf("[server] Client reached! Recieved ID: %d\n", id);

        int pid = fork();
        if (pid < 0)
        {
            perror("[server] fork() failure");
            close(client_socket);
            continue;
        }

        if (pid == 0)
        {

            close(server_socket);
            client_handler(client_socket, id);
            exit(0);
        }
        else
        {
            close(client_socket);
        }
    }

    close(server_socket);
    return 0;
}
