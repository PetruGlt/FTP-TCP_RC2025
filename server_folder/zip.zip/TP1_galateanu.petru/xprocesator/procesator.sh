#!/bin/bash

if [ "$#" -ne 1 ] || [ ! -d "$1" ]; then
    echo "Usage: $0 directory" >&2
    exit 2
fi


if [ ! -f "validators/default.sh" ]; then
    echo "Error: 'default.sh' not found in 'validators' directory." >&2
    exit 1
fi

if [ ! -x "validators/default.sh" ]; then
    echo "Error: 'default.sh' does not have execution permission." >&2
    exit 1
fi

if [ ! -d "$1" ]; then
    echo "Error: Directory '$1' not found.">&2
    exit 3
fi

if [ ! -r "$1" ];then 
    echo "Error: '$1' does not have reading permission.">&2
    exit 3
fi

parcurge() {
    for file in "$1"/*; do
        if [ -d "$file" ]; then
            parcurge "$file"
        elif [ -f "$file" ] && [ -r "$file" ]; then
            validators/default.sh "$file" >> results.txt
        fi
    done
}

parcurge "$1"