#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "No argument given." >&2
    exit 2
fi

if [ ! -f "validators/validatoraASCII" ] || [ "validators/validatorASCII.c" -nt "validators/validatorASCII" ]; then
    gcc "validators/validatorASCII.c" -o "validators/validatorASCII" 
    if [ $? -ne 0 ]; then
        echo "Error: Failed to compile alphanumeric.c" >&2
        exit 3
    fi
fi

echo validatorASCII<"$1" |  # inlocuim la afisare caracterul : cu caracterul > 
