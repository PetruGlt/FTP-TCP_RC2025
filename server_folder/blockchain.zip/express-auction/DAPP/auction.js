var contractAddress = "0x7b09b584DF4587f1d258b20047BEED1131B5B155"; // address in Ganache - change this to yours

const ethEnabled = () => {
    // EIP-1193: Ethereum Provider JavaScript API  - https://eips.ethereum.org/EIPS/eip-1193
    if (window.ethereum) {
        window.web3 = new Web3(window.ethereum);
        return true;
    }
    return false;
}

if (!ethEnabled()) {
    alert("Please install an Ethereum-compatible browser or extension like MetaMask to use this dApp!");
}

window.onload = async function init() {

    // RPC methods https://eips.ethereum.org/EIPS/eip-1474
    // https://docs.metamask.io/guide/getting-started.html#connecting-to-metamask
    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    window.bidder = accounts[0];
    console.log(accounts);

    //web3.eth.defaultAccount = bidder;
    var myauctionContractABI = [{"inputs":[],"name":"bid","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_biddingTime","type":"uint256"},{"internalType":"address payable","name":"_owner","type":"address"},{"internalType":"string","name":"_brand","type":"string"},{"internalType":"string","name":"_Rnumber","type":"string"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"highestBidder","type":"address"},{"indexed":false,"internalType":"uint256","name":"highestBid","type":"uint256"}],"name":"BidEvent","type":"event"},{"inputs":[],"name":"cancel_auction","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"string","name":"message","type":"string"},{"indexed":false,"internalType":"uint256","name":"time","type":"uint256"}],"name":"CanceledEvent","type":"event"},{"inputs":[],"name":"withdraw","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"withdrawer","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"WithdrawalEvent","type":"event"},{"stateMutability":"payable","type":"fallback"},{"stateMutability":"payable","type":"receive"},{"inputs":[],"name":"auction_end","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"auction_start","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"bids","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"get_owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"highestBid","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"highestBidder","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"Mycar","outputs":[{"internalType":"string","name":"Brand","type":"string"},{"internalType":"string","name":"Rnumber","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"STATE","outputs":[{"internalType":"enum Auction.auction_state","name":"","type":"uint8"}],"stateMutability":"view","type":"function"}]

    window.auction = new web3.eth.Contract(myauctionContractABI, contractAddress);

    auction.methods.auction_end().call().then(function (endTimestamp) {
        const tsMs = endTimestamp * 1000n; // convert to ms
        const endDate = new Date(Number(tsMs));
        document.getElementById("auction_end").innerHTML = endDate.toLocaleString();
    });

    auction.methods.highestBidder().call().then(function (result) {
        document.getElementById("HighestBidder").innerHTML = result;
    });

    auction.methods.highestBid().call().then(function (result) {
        var bidEther = web3.utils.fromWei(result, 'ether');
        document.getElementById("HighestBid").innerHTML = bidEther;
    });

    auction.methods.STATE().call().then(function (result) {
        switch (result) {
            case 0n:
                result = 'Canceled';
                break;
            case 1n:
                result = 'Running';
                break;
        }
        document.getElementById("STATE").innerHTML = result;
    });

    auction.methods.Mycar().call().then(function (result) {
        document.getElementById("car_brand").innerHTML = result[0];
        document.getElementById("registration_number").innerHTML = result[1];
    });

    auction.methods.bids(bidder).call().then(function (result) {
        var bidEther = web3.utils.fromWei(result, 'ether');
        document.getElementById("MyBid").innerHTML = bidEther;
    });

    var auction_owner = null;
    auction.methods.get_owner().call().then(function (result) {

        auction_owner = result;
        console.log('auction_owner', auction_owner);
        console.log(bidder.toLowerCase(), auction_owner.toLowerCase());
        if (bidder.toLowerCase() != auction_owner.toLowerCase()) {
            $("#auction_owner_operations").hide();
        }
    });


    const pastEvents = await auction.getPastEvents('BidEvent', {
        fromBlock: 0,
        toBlock: 'latest'
    });

    pastEvents.forEach((bidEvent) => {
        $("#eventslog").append(bidEvent.returnValues.highestBidder + ' has bidden(' + bidEvent.returnValues.highestBid * 10n ** 18n + ' ETH)<br>');
    });


    /*filter.get(callback): Returns all of the log entries that fit the filter.
    filter.watch(callback): Watches for state changes that fit the filter and calls the callback. See this note for details.*/
    // https://docs.web3js.org/api/web3-eth-contract/class/LogsSubscription
    auction.events.BidEvent(
        {
            filter: {
                fromBlock: 0,
                toBlock: 'latest',
                address: contractAddress,
                // topics: [web3.utils.sha3('BidEvent(address,uint256)')]
            }
        }
    ).on('data', function (event) {
        $("#eventslog").append(event.returnValues.highestBidder + ' has bidden(' + event.returnValues.highestBid + ' wei) <br>');
        console.log(event); // same results as the optional callback above
    });

    auction.events.CanceledEvent()
        .on('data', function (event) {
            $("#eventslog").html(event.returnValues.message + ' at ' + event.returnValues.time);
        });
}

//alternative to ethereum.request({ method: 'eth_requestAccounts' });
ethereum.on('accountsChanged', function (accounts) {
    window.bidder = accounts[0];
});

document.getElementById("bid_button").onclick = function () {
    const mybid = document.getElementById('value').value;
    // Automatically determines the use of call or sendTransaction based on the method type
    auction.methods.bid().send(
        {
            from: window.bidder,
            value: web3.utils.toWei(mybid, "ether"),
            gas: 200000
        })
        .then(result => {
            console.log(result);
            document.getElementById("biding_status").innerHTML = "Successfull bid, transaction ID" + result.transactionHash;
        })
        .catch(error => {
            console.log("error is ", error);
            document.getElementById("biding_status").innerHTML = "Think to bidding higher";
        });
}

document.getElementById("cancel_button").onclick = async function () {
    try {
        const result = await auction.methods.cancel_auction().send({
            from: window.bidder
        });

        console.log(result);
    } catch (error) {
        console.log(error);
    }
}


