
Contract - pentru deployment se va folosi Remix:
auction.sol - include contractele pentru o simulare de licitatie (nota: nu exista finalitate, banii trebuie retrasi manual la final via Remix din contract de fiecare bidder)

Aplicatie - foloseste Express pentru web server:
DAPP/index.html - pagina web pentru o simulare de licitatie (nota: nu exista suport complet pentru retragere fonduri, banii trebuie retrasi manual prin contract la final)
DAPP/auction.js - interfata programata folosind web3 pentru comunicarea cu Ethereum
DAPP/server.js - rulare server local pentru servire pagina web (altfel Metamask nu injecteaza provider in browser)
DAPP/package.json - pachete necesare server

Rulare (din directorul DAPP):
npm install
npm start


